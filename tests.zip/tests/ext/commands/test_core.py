from typing import TYPE_CHECKING

from disnake.ext import commands

if TYPE_CHECKING:
    from typing_extensions import assert_type

    # NOTE: using undocumented `expected_text` parameter of pyright instead of `assert_type`,
    # as `assert_type` can't handle bound ParamSpecs
    #
    # sanity check: if `reveal_type` isn't working as intended,
    # the second `type: ignore` will be flagged
    reveal_type(  # noqa: F821
        42,  # type: ignore
        expected_text="str",  # type: ignore
    )


class CustomContext(commands.Context):
    ...


class CustomCog(commands.Cog):
    ...


class TestDecorators:
    def _test_typing_defaults(self):
        base = commands.GroupMixin[None]()

        # no cog

        async def f1(ctx: CustomContext, a: int, b: str) -> bool:
            ...

        for cd in (commands.command(), base.command()):
            reveal_type(  # noqa: F821
                cd(f1),  # type: ignore
                expected_text="Command[None, (a: int, b: str), bool]",
            )

        for gd in (commands.group(), base.group()):
            reveal_type(  # noqa: F821
                gd(f1),  # type: ignore
                expected_text="Group[None, (a: int, b: str), bool]",
            )

        # custom cog
        base = commands.GroupMixin[CustomCog]()

        async def f2(_self: CustomCog, ctx: CustomContext, a: int, b: str) -> bool:
            ...

        for cd in (commands.command(), base.command()):
            reveal_type(  # noqa: F821
                cd(f2),  # type: ignore
                expected_text="Command[CustomCog, (a: int, b: str), bool]",
            )

        for gd in (commands.group(), base.group()):
            reveal_type(  # noqa: F821
                gd(f2),  # type: ignore
                expected_text="Group[CustomCog, (a: int, b: str), bool]",
            )

    def _test_typing_cls(self):
        class CustomCommand(commands.Command):
            ...

        class CustomGroup(commands.Group):
            ...

        base = commands.GroupMixin[None]()

        command_decorators = (commands.command(cls=CustomCommand), base.command(cls=CustomCommand))
        group_decorators = (commands.group(cls=CustomGroup), base.group(cls=CustomGroup))

        async def f(ctx: CustomContext, a: int, b: str) -> bool:
            ...

        for cd in command_decorators:
            assert_type(cd(f), CustomCommand)

        for gd in group_decorators:
            assert_type(gd(f), CustomGroup)
